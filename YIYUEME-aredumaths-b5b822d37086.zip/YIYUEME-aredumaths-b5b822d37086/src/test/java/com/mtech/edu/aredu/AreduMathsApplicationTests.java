package com.mtech.edu.aredu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AreduMathsApplicationTests {

	@Test
	void contextLoads() {
	}

}
