package com.mtech.edu.aredu.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mtech.edu.aredu.entities.Notion;

public interface NotionRepository extends JpaRepository<Notion, Long>{

}
