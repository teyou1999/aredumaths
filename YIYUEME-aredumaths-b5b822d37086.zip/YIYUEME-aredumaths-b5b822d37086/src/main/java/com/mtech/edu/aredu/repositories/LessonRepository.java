package com.mtech.edu.aredu.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mtech.edu.aredu.entities.Lesson;


public interface LessonRepository extends JpaRepository<Lesson, Integer>{

}
