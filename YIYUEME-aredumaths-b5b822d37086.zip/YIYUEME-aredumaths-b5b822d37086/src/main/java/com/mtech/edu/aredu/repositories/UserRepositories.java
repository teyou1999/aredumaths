package com.mtech.edu.aredu.repositories;

import org.springframework.data.repository.CrudRepository;

import com.mtech.edu.aredu.entities.User;

public interface UserRepositories<T extends User> extends CrudRepository<T,Long>{

}
