package com.mtech.edu.aredu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.ResourceAccessException;

import com.mtech.edu.aredu.entities.Lesson;
import com.mtech.edu.aredu.repositories.ChapterRepository;
import com.mtech.edu.aredu.repositories.LessonRepository;

@RestController
public class LessonController {
	@Autowired
	LessonRepository repository;
	@Autowired
	ChapterRepository chapterRepo;

	@RequestMapping(value = "/lesson", method = RequestMethod.GET)
	public List<Lesson> getAllLesson(){
		return (List<Lesson>)repository.findAll();
	}

	@RequestMapping(value = "/lesson/{idLesson}", method = RequestMethod.GET)
	public Lesson getLesson(@PathVariable("idLesson") int idLesson) {
		return repository.findById(idLesson).get();
	}

	@RequestMapping(value = "/chapter/{idChapter}/lesson", method = RequestMethod.POST)
	public ResponseEntity<Lesson> createLesson(@PathVariable(value="idChapter") int idChapter ,@RequestBody Lesson lessonRequest) {
		
		Lesson lesson = chapterRepo.findById(idChapter).map(chapter -> {
		      lessonRequest.setChapter(chapter);
		      return repository.save(lessonRequest);
		    }).orElseThrow(() -> new ResourceAccessException("Not found Chapter with id = " + idChapter));
		    return new ResponseEntity<>(lesson, HttpStatus.CREATED);
		
		 
	}

	@RequestMapping(value = "/lesson", method = RequestMethod.PUT)
	public Lesson updateLesson(@RequestBody Lesson lesson) {
		return repository.save(lesson);
	}

	@RequestMapping(value = "/lesson/{idLesson}", method = RequestMethod.DELETE)
	public void deleteByIdLesson(@PathVariable("idLesson") int idLesson) {
		repository.deleteById(idLesson);
	}

	@RequestMapping(value = "/lesson", method = RequestMethod.DELETE)
	public void deleteLesson(@RequestBody Lesson lesson){
		repository.delete(lesson);
	}

}
