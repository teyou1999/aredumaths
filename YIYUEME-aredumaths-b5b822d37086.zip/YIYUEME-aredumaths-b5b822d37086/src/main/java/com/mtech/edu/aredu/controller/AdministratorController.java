package com.mtech.edu.aredu.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mtech.edu.aredu.entities.Admin;
import com.mtech.edu.aredu.repositories.UserRepositories;

@RestController
public class AdministratorController {
    @Autowired
    private UserRepositories<Admin> repository;
    //EntityManagerFactory emf = Persistence.createEntityManagerFactory("monUniteDePersistance");

    

    @RequestMapping(value="/admin",method=RequestMethod.GET)
    public List<Admin> getAdmins(){
        return (List<Admin>) repository.findAll();

    }
    @RequestMapping(value="/admin/{idUser}",method=RequestMethod.GET)
    public Admin getAdmin(@PathVariable("idUser") long idUser) {
    	return repository.findById(idUser).get();
    }
    @RequestMapping(value="/admin",method=RequestMethod.POST)
    public Admin createAdmin(@RequestBody Admin admin) {
    	/*EntityManager entityManager = emf.createEntityManager();
    	entityManager.persist(admin);*/
    	return repository.save(admin);
    }
    @RequestMapping(value="/admin",method=RequestMethod.PUT)
    public Admin updateAdmin(@RequestBody Admin admin) {
    	return repository.save(admin);
    }
    @RequestMapping(value="/admin",method=RequestMethod.DELETE)
    public void deleteAdmin(@RequestBody Admin admin) {
    	 repository.delete(admin);
    }


}
