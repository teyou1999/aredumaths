package com.mtech.edu.aredu.entities;

import java.io.File;
import java.util.HashSet;
//import java.util.Set;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "notions")
public class Notion {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String libelle;
	@Column
	private String description;
	@Column
	private File ressource;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "idLesson", nullable = false)
	@JsonIgnore
	private Lesson lesson;
	@ManyToMany(fetch = FetchType.LAZY,
		      cascade = {
		          CascadeType.PERSIST,
		          CascadeType.MERGE
		      },
		      mappedBy = "dispensedNotions")
	@JsonIgnore  
	private Set<Teacher> dispense=new HashSet<>();
	
	@ManyToMany(fetch = FetchType.LAZY,
		      cascade = {
		          CascadeType.PERSIST,
		          CascadeType.MERGE
		      },
		      mappedBy = "followedNotions")
	@JsonIgnore  
	private Set<Student> follow=new HashSet<>();
	
	public Notion() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Notion(int id, String libelle, String description, File ressource, Lesson lessons, Set<Teacher> dispense,
			Set<Student> follow) {
		super();
		this.id = id;
		this.libelle = libelle;
		this.description = description;
		this.ressource = ressource;
		this.lesson = lessons;
		this.dispense = dispense;
		this.follow = follow;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibele(String libelle) {
		this.libelle = libelle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public File getRessource() {
		return ressource;
	}
	public void setRessource(File ressource) {
		this.ressource = ressource;
	}
	public Lesson getLessons() {
		return lesson;
	}
	public void setLessons(Lesson lessons) {
		this.lesson = lessons;
	}
	public Set<Teacher> getDispense() {
		return dispense;
	}
	public void setDispense(Set<Teacher> dispense) {
		this.dispense = dispense;
	}
	public Set<Student> getFollow() {
		return follow;
	}
	public void setFollow(Set<Student> follow) {
		this.follow = follow;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	
	
}
