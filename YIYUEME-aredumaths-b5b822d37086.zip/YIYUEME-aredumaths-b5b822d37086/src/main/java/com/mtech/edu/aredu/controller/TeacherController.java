package com.mtech.edu.aredu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
 
import org.springframework.web.bind.annotation.ResponseBody;
 
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.ResourceAccessException;

import com.mtech.edu.aredu.entities.Notion;
import com.mtech.edu.aredu.entities.Student;
import com.mtech.edu.aredu.entities.Teacher;
import com.mtech.edu.aredu.repositories.NotionRepository;
import com.mtech.edu.aredu.repositories.UserRepositories;
 
 

 
@RestController
public class TeacherController {
	@Autowired
    private UserRepositories<Teacher> repository;
	@Autowired
    private NotionRepository notionRepository;
	 @RequestMapping(value="/teacher",method=RequestMethod.GET)
	 public List<Teacher> getAllTeachers(){
		 return (List<Teacher>) repository.findAll();
	 }
	@RequestMapping(value="/teacher/{idUser}",method=RequestMethod.GET)
	public Teacher getTeacher(@PathVariable("idUser") long idUser) {
		return repository.findById(idUser).get();
	}
	@RequestMapping(value="/teacher",method=RequestMethod.POST)
	public @ResponseBody Teacher createTeacher(@RequestBody Teacher teacher) {
		return repository.save(teacher);
	}
	@RequestMapping(value="/teacher",method=RequestMethod.PUT)
	public Teacher updateTeacher(@RequestBody Teacher teacher) {
		return repository.save(teacher);
	}
	@RequestMapping(value="/teacher/{idUser}",method=RequestMethod.DELETE)
	public void deleteTeacherById(@PathVariable("idUser") long idUser) {
		repository.deleteById(idUser);
	}
	@RequestMapping(value="/teacher",method=RequestMethod.DELETE)
	public void deleteTeacher(@RequestBody Teacher teacher) {
		repository.delete(teacher);
	}
	@RequestMapping(value="/teacher/{idTeacher}",method=RequestMethod.PUT)
	public ResponseEntity<Teacher> addNotion(@PathVariable("idTeacher") long idTeacher,@RequestBody Teacher teacher) {
		Teacher _teacher = repository.findById(idTeacher)
		        .orElseThrow(() -> new ResourceAccessException("Not found Teacher with id = " + idTeacher));
		    _teacher.setName(teacher.getName());
		    _teacher.setAvatar(teacher.getAvatar());
		    _teacher.setLogin(teacher.getLogin());
		    _teacher.setEmail(teacher.getEmail());
		    _teacher.setPassword(teacher.getPassword());
		    _teacher.setTel(teacher.getTel());
		    
		    return new ResponseEntity<>(repository.save(_teacher), HttpStatus.OK);
	}

}
