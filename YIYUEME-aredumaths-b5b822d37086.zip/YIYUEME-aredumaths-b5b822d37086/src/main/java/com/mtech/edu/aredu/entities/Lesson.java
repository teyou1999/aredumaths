package com.mtech.edu.aredu.entities;

import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
//@DiscriminatorColumn(name="lesson")
@Table(name = "lessons")
public class Lesson {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idLesson;
	@Column
	private String libelle;
	@Column
	private String description;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name="idChapter",nullable=false)
	@JsonIgnore
    private Chapter chapter;
	public int getIdLesson() {
		return idLesson;
	}
	public void setIdLesson(int idLesson) {
		this.idLesson = idLesson;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Chapter getChapter() {
		return chapter;
	}
	public void setChapter(Chapter chapter) {
		this.chapter = chapter;
	}
	
	
}
