package com.mtech.edu.aredu.controller;

import java.util.List;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mtech.edu.aredu.entities.Lesson;
import com.mtech.edu.aredu.entities.Notion;
import com.mtech.edu.aredu.entities.Student;
import com.mtech.edu.aredu.entities.Teacher;
import com.mtech.edu.aredu.repositories.LessonRepository;
import com.mtech.edu.aredu.repositories.NotionRepository;
import com.mtech.edu.aredu.repositories.UserRepositories;
import org.springframework.web.client.ResourceAccessException;

@RestController
public class NotionController {
	@Autowired
	NotionRepository repository;
	@Autowired
	UserRepositories<Teacher> teacherRepo;
	@Autowired
	UserRepositories<Student> studentRepo;
	@Autowired
	LessonRepository lessonRepo;
	@RequestMapping(value = "/notion", method = RequestMethod.GET)
	public List<Notion> getAllNotion(){
		return (List<Notion>)repository.findAll();
	}
	
	@RequestMapping(value = "/notion/{idNotion}", method = RequestMethod.GET)
	public Notion getNotionById(@PathVariable("idNotion") Long idNotion) {
		return repository.findById(idNotion).get();
	}
	
	@RequestMapping(value = "/lesson/{idLesson}/teacher/{idTeacher}/notion", method = RequestMethod.POST)
	public ResponseEntity<Notion> createNotion(@PathVariable(value = "idLesson") int idLesson ,@PathVariable(value = "idTeacher") Long idTeacher ,@RequestBody Notion notionRequest) {
		
		Lesson lesson=lessonRepo.findById(idLesson).get() ;
		
		Notion notion = teacherRepo.findById(idTeacher).map(teacher -> {
		      long idNotion = notionRequest.getId();
		      
		      
		      
		      // tag is existed
		      if (idNotion != 0L) {
		        Notion _notion = repository.findById(idNotion)
		            .orElseThrow(() -> new ResourceAccessException("Not found Notion with id = " + idNotion));
		        _notion.setLessons(lesson);
		        teacher.addNotion(_notion);
		        teacherRepo.save(teacher);
		        return _notion;
		      }
		      
		      // add and create new Tag
		      notionRequest.setLessons(lesson);
		      teacher.addNotion(notionRequest);
		      return repository.save(notionRequest);
		    }).orElseThrow(() -> new ResourceAccessException("Not found Teacher with id = " + idTeacher));
		    return new ResponseEntity<>(notion, HttpStatus.CREATED);
		 
		 
	}
	
	@RequestMapping(value = "/notion", method = RequestMethod.PUT)
	public Notion updateNotion(@RequestBody Notion notion) {
		return repository.save(notion);
	}
	
	@RequestMapping(value = "/notion/{idNiton}", method = RequestMethod.DELETE)
	public void deleteNotionById(@PathVariable("idNotion") Long idNotion) {
		repository.deleteById(idNotion);
	}

	@RequestMapping(value = "/notion", method = RequestMethod.DELETE)
	public void deleteNotion(@RequestBody Notion notion) {
		repository.deleteAll();
	}
	
	@RequestMapping(value = "/student/{idStudent}/notion", method = RequestMethod.PUT)
	public ResponseEntity<Notion> followNotion(@PathVariable(value = "idStudent") Long idStudent ,@RequestBody Notion notionRequest) {
		
		Notion notion = studentRepo.findById(idStudent).map(student -> {
		      long idNotion = notionRequest.getId();
		      
		      // tag is existed
		      if (idNotion != 0L) {
		        Notion _notion = repository.findById(idNotion)
		            .orElseThrow(() -> new ResourceAccessException("Not found Notion with id = " + idNotion));
		        student.addNotion(_notion);
		        studentRepo.save(student);
		        return _notion;
		      }
		      
		      // add and create new Tag
		      student.addNotion(notionRequest);
		      return repository.save(notionRequest);
		    }).orElseThrow(() -> new ResourceAccessException("Not found Student with id = " + idStudent));
		    return new ResponseEntity<>(notion, HttpStatus.CREATED);
		 
		 
	}

}
