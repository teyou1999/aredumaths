package com.mtech.edu.aredu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.mtech.edu.aredu.entities.Admin;
import com.mtech.edu.aredu.entities.Student;
import com.mtech.edu.aredu.repositories.UserRepositories;

@RestController
public class StudentController {
	@Autowired
    private UserRepositories<Student> repository;
	 @RequestMapping(value="/student",method=RequestMethod.GET)
	 public List<Student> getAllStudents(){
		 return (List<Student>) repository.findAll();
	 }
	@RequestMapping(value="/student/{idUser}",method=RequestMethod.GET)
	public Student getStudent(@PathVariable("idUser") long idUser) {
		return repository.findById(idUser).get();
	}
	@RequestMapping(value="/student",method=RequestMethod.POST)
	public Student createStudent(@RequestBody Student student) {
		return repository.save(student);
	}
	@RequestMapping(value="/student",method=RequestMethod.PUT)
	public Student updateStudent(@RequestBody Student student) {
		return repository.save(student);
	}
	@RequestMapping(value="/student/{idUser}",method=RequestMethod.DELETE)
	public void deleteStudentById(@PathVariable("idUser") long idUser) {
		repository.deleteById(idUser);
	}
	@RequestMapping(value="/student",method=RequestMethod.DELETE)
	public void deleteStudent(@RequestBody Student student) {
		repository.delete(student);
	}

}
