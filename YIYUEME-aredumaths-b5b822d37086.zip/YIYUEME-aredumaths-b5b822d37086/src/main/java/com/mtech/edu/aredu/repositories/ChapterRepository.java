package com.mtech.edu.aredu.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mtech.edu.aredu.entities.Chapter;

public interface ChapterRepository extends JpaRepository<Chapter, Integer>{

	
}