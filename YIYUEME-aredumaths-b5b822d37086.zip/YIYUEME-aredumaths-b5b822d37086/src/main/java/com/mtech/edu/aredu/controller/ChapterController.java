package com.mtech.edu.aredu.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mtech.edu.aredu.entities.Admin;
import com.mtech.edu.aredu.entities.Chapter;
import com.mtech.edu.aredu.repositories.ChapterRepository;
import com.mtech.edu.aredu.repositories.UserRepositories;

@RestController
public class ChapterController {
	@Autowired
	ChapterRepository repository;
	@Autowired
	UserRepositories<Admin> adminRepo ;
	//EntityManagerFactory emf = Persistence.createEntityManagerFactory("monUniteDePersistance");

	
	
	@RequestMapping(value = "/chapter", method = RequestMethod.GET)
	public List<Chapter> getAllChapter(){
		return (List<Chapter>)repository.findAll();
	}
	
	@RequestMapping(value = "/chapter/{idchapter}", method = RequestMethod.GET)
	public Chapter getChapter(@PathVariable("idChapter") int idChapter) {
		return repository.findById(idChapter).get();
	}
	@RequestMapping(value = "/admin/{idAdmin}/chapter", method = RequestMethod.POST)
	public ResponseEntity<Chapter> createChapter(@PathVariable(value = "idAdmin")Long idAdmin , @RequestBody Chapter chapter) {
		 
		 Chapter chapter1=adminRepo.findById(idAdmin).map(admin -> {
			 chapter.setAdmin(admin);
			 return repository.save(chapter);
			 
		 }).orElseThrow();
		    return new ResponseEntity<>(chapter, HttpStatus.CREATED);
		//return repository.save(chapter1);
	}
	
	@RequestMapping(value = "/chapter", method = RequestMethod.PUT)
	public Chapter updateChapter(@RequestBody Chapter chapter) {
		return repository.save(chapter);
	}
	
	@RequestMapping(value = "/chapter/{idChapter}", method = RequestMethod.DELETE)
	public void deleteChapterById(@PathVariable("idChapter") int idChapter) {
		repository.deleteById(idChapter);
	}

	@RequestMapping(value = "/chapter", method = RequestMethod.DELETE)
	public void deleteChapter(@RequestBody Chapter chapter) {
		repository.delete(chapter);
	}
	
}
