package com.mtech.edu.aredu.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@DiscriminatorColumn(name="student")
@Table(name = "students")
public class Student extends User{
	
	@ManyToMany(fetch = FetchType.LAZY,
		      cascade = {
		          CascadeType.PERSIST,
		          CascadeType.MERGE
		      })
		  @JoinTable(name = "followed",
		        joinColumns = { @JoinColumn(name = "teacher_id") },
		        inverseJoinColumns = { @JoinColumn(name = "notion_id") })
   private Set<Notion> followedNotions;
	public void addNotion(Notion notion) {
		this.followedNotions.add(notion);
		notion.getFollow().add(this);
	}
	
	public void removeNotions(long idNotion) {
		 Notion notion = this.followedNotions.stream().filter(t -> t.getId() == idNotion).findFirst().orElse(null);
		    if (notion != null) {
		      this.followedNotions.remove(notion);
		      notion.getFollow().remove(this);
		    }
		
	}
	



	 

	 
}



