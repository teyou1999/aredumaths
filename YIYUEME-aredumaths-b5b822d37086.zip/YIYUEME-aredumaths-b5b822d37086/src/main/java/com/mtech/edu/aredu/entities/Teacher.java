package com.mtech.edu.aredu.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@DiscriminatorColumn(name="teacher")
@Table(name = "teachers")
public class Teacher extends User {
	
	 
	 
	@ManyToMany(fetch = FetchType.LAZY,
		      cascade = {
		          CascadeType.PERSIST,
		          CascadeType.MERGE
		      })
		  @JoinTable(name = "dispensed",
		        joinColumns = { @JoinColumn(name = "teacher_id") },
		        inverseJoinColumns = { @JoinColumn(name = "notion_id") })
	private Set<Notion> dispensedNotions = new HashSet<>();

	public Teacher(Set<Notion> dispensedNotions) {
		super();
		this.dispensedNotions = dispensedNotions;
	}

	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void addNotion(Notion notion) {
		this.dispensedNotions.add(notion);
		notion.getDispense().add(this);
	}
	
	public void removeNotions(long idNotion) {
		 Notion notion = this.dispensedNotions.stream().filter(t -> t.getId() == idNotion).findFirst().orElse(null);
		    if (notion != null) {
		      this.dispensedNotions.remove(notion);
		      notion.getDispense().remove(this);
		    }
		
	}

}
