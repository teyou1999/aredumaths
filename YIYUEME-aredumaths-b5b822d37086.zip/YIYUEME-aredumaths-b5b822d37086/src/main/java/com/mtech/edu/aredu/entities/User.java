package com.mtech.edu.aredu.entities;

import java.io.File;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
@DiscriminatorColumn(name="account_type")
@Table(name = "users")
public abstract class  User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "name")
	private String name;
	@Column(name = "surname")
	private String surname;
	@Column(name = "email")
	private String email;
	@Column(name = "login")
	private String login;
	@Column(name = "password")
	private String password;
	@Column(name = "tel")
	private String tel;
	@Column(name = "avatar")
	private File avatar;
	
	public User(String name, String surname, String email, String login, String password, String tel,
			File avatar) {
		super();
		
		this.name = name;
		this.surname = surname;
		this.email = email;
		this.login = login;
		this.password = password;
		this.tel = tel;
		this.avatar = avatar;
	}
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(long id, String name, String surname, String email, String login, String password, String tel,
			File avatar) {
		super();
		this.id = id;
		this.name = name;
		this.surname = surname;
		this.email = email;
		this.login = login;
		this.password = password;
		this.tel = tel;
		this.avatar = avatar;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public File getAvatar() {
		return avatar;
	}
	public void setAvatar(File avatar) {
		this.avatar = avatar;
	}
	 
	 
	 
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	

}
